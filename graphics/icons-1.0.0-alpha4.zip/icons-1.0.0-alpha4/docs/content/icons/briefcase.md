---
title: Briefcase
categories:
  - Real world
tags:
  - business
---
