---
title: Check2
layout: icon
categories:
  - UI and keyboard
tags:
  - checkmark
  - todo
  - select
  - done
  - checkbox
---
