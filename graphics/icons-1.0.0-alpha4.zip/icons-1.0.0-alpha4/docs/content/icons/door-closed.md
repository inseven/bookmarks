---
title: Door closed
layout: icon
categories:
  - Real world
tags:
  - door
  - logout
  - signout
---
