---
title: Emoji frown
layout: icon
categories:
  - Emoji
tags:
  - emoticon
  - sad
---
