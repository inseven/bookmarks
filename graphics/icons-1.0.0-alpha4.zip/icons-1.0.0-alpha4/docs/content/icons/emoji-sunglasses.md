---
title: Emoji sunglasses
layout: icon
categories:
  - Emoji
tags:
  - emoticon
  - cool
---
