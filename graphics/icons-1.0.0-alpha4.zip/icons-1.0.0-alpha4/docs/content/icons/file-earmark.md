---
title: File earmark
categories:
  - Files and folders
tags:
  - doc
  - document
---
