---
title: File ruled
categories:
  - Files and folders
tags:
  - doc
  - document
---
