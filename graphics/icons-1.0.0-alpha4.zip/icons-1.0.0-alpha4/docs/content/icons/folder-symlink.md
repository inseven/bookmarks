---
title: Folder symlink
categories:
  - Files and folders
tags:
  - directory
  - symbolic-link
---
