---
title: Folder
categories:
  - Files and folders
tags:
  - directory
---
