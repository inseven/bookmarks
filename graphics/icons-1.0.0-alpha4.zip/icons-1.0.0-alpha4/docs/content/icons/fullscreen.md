---
title: Fullscreen
categories:
  - UI and keyboard
tags:
  - window
  - maximize
---
