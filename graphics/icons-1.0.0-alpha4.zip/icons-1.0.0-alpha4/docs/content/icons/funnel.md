---
title: Funnel
categories:
  - Real world
tags:
  - sort
  - filter
---
