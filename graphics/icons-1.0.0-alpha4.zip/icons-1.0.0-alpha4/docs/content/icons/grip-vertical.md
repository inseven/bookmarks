---
title: Grip vertical
layout: icon
categories:
  - UI and keyboard
tags:
  - drag
  - grab
---
