---
title: Hand index thumb
layout: icon
categories:
  - Hands
tags:
  - hand
  - pointer
  - cursor
---
