---
title: Hand index
layout: icon
categories:
  - Hands
tags:
  - hand
  - pointer
  - cursor
---
