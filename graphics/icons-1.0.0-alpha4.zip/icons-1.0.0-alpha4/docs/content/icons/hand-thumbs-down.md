---
title: Hand thumbs down
layout: icon
categories:
  - Hands
tags:
  - hand
  - pointer
  - thumbs-down
  - "-1"
---
