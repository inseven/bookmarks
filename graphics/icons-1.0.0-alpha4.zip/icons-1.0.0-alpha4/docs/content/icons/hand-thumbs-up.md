---
title: Hand thumbs up
layout: icon
categories:
  - Hands
tags:
  - hand
  - pointer
  - thumbs-up
  - "+1"
---
