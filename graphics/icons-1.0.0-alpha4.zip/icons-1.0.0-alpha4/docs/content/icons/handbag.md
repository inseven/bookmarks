---
title: Handbag
layout: icon
categories:
  - Real world
tags:
  - purse
  - tote
---
