---
title: Heart half
categories:
  - Shapes
tags:
  - love
  - favorite
---
