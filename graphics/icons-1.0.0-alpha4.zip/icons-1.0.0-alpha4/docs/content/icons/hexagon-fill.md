---
title: Hexagon fill
layout: icon
categories:
  - Shapes
tags:
  - shape
  - polygon
---
