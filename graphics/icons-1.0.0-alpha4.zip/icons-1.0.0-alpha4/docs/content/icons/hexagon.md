---
title: Hexagon
layout: icon
categories:
  - Shapes
tags:
  - shape
  - polygon
---
