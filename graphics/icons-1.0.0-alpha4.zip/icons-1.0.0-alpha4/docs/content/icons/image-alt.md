---
title: Image alt
categories:
  - Files and folders
tags:
  - picture
  - photo
---
