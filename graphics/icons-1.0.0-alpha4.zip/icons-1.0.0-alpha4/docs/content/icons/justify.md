---
title: Justify
categories:
  - Typography
tags:
  - text
  - type
  - justify
  - alignment
---
