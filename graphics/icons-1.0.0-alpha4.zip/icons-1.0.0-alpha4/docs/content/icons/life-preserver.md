---
title: Life preserver
categories:
  - Real world
tags:
  - lifesaver
  - water
---
