---
title: Lightning fill
categories:
  - Misc
tags:
  - weather
  - storm
  - thunder
  - bolt
---
