---
title: Link 45deg
categories:
  - UI and keyboard
tags:
  - anchor
  - hyperlink
  - href
---
